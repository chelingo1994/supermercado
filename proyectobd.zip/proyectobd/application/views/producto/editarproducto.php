<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h1 class="text-white my-5 text-center"><?php echo $title ?></h1>
<form action="<?php echo base_url('producto/actualizar/'.$productos->codproducto); ?>" method="POST" class="text-light bg-dark rounded-4 border border-light p-4 mx-auto" style="max-width: 300px;">
  <div class="mb-3">
    <label for="ci" class="form-label">ID:</label>
    <?php echo $productos->codproducto ?>
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Nombre:</label>
    <input type="text" class="form-control bg-white text-dark border" id="nombre" name="nombre" value="<?php echo $productos->nombre; ?>">
  </div>
  <div class="mb-3">
    <label for="descripcion" class="form-label">Descripcion:</label>
    <textarea name="descripcion" class="form-control bg-white text-dark border" id="descripcion" ><?php echo $productos->descripcion; ?></textarea>
  </div>
  <div class="mb-3">
    <label for="precio" class="form-label">Precio:</label>
    <input type="number" step="0.01" class="form-control bg-white text-dark border" id="precio" name="precio" value="<?php echo $productos->precio; ?>">
  </div>
  <div class="mb-3">
    <label for="stock" class="form-label">Stock:</label>
    <input type="text" class="form-control bg-white text-dark border" id="stock" name="stock" value="<?php echo $productos->stock ?>">
  </div>
  <div class="mb-3">
    <label for="categoria" class="form-label">Categoria:</label>
    <select name="categoria" class="form-control bg-white text-dark border" id="categoria">
      <?php foreach ($categorias as $categoria): ?>
      <option value="<?php echo $categoria->codcategoria ?>"
      <?php echo ($categoria->codcategoria==$productos->codcategoria)? 'selected':'' ?>>
      <?php echo $categoria->nombre ?></option>
      <?php endforeach;?>
    </select>
  </div>
  <div class="d-flex justify-content-center p-2">
    <button type="submit" class="btn btn-primary">Editar Producto</button>
  </div>
</form> 


