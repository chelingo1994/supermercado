<h1 class="text-center my-5" style="color: white;">Lista de Productos</h1>

<div class="table-responsive px-5 d-flex">
  <table class="table table-bordered table-dark table-striped">
    <thead>
      <tr class="text-center">
        <th scope="col">ID</th>
        <th scope="col">Nombre</th>
        <th scope="col">Descripcion</th>
        <th scope="col">Precio</th>
        <th scope="col">Stock</th>
        <th scope="col">Categoria</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead>
    <tbody>

      <?php if(!empty($productos)): ?>
        <?php foreach($productos as $producto): ?>
          <tr>
            <th scope="row"><?php echo $producto->codproducto; ?></th>
            <td><?php echo $producto->nombre; ?></td>
            <td><?php echo $producto->descripcion; ?></td>
            <td><?php echo $producto->precio; ?></td>
            <td><?php echo $producto->stock; ?></td>
            <td><?php echo $producto->nombrecat; ?></td>
            <td>
              <div class="d-flex">
                <a class="btn btn-warning m-1" href="<?php echo base_url('producto/edit/'.$producto->codproducto.'');?>" role="button">Editar</a>
                
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#confirmDeleteModal<?php echo $producto->codproducto; ?>">
                  Borrar
                </button>

                <div class="modal fade" id="confirmDeleteModal<?php echo $producto->codproducto; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Confirmar Borrado</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        ¿Estás seguro de que deseas eliminar al Producto: "<?php echo $producto->nombre; ?>"?
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <form action="<?php echo base_url('producto/eliminar/'.$producto->codproducto.''); ?>" method="post">
                          <button type="submit" class="btn btn-danger">Borrar</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </td>
          </tr>
        <?php endforeach;?>
      <?php else:?>
        <tr>
          <td colspan="7" class="text-center fs-5">No hay Proveedores</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>




