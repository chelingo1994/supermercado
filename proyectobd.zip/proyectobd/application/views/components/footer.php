 <footer class="bg-dark w-100 pb-2 pt-5 px-5">
    <p class="text-center text-white border-top border-secondary py-3">&copy; 2025 Mi proyecto</p>
  </footer>