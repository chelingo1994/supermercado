 <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo base_url('principal');?>">Mi proyecto</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Cliente
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo base_url('cliente/registrar_Formu');?>">Registra Cliente</a>
              <li><a class="dropdown-item" href="<?php echo base_url('cliente/listarclientes');?>">Listar Clientes</a>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Empleado
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo base_url('empleado/registrar_Formu');?>">Registra Empleado</a>
              <li><a class="dropdown-item" href="<?php echo base_url('empleado/listarempleados');?>">Listar Empleados</a>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Categoria
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo base_url('categoria/registrar_Formu');?>">Registra Categoria</a>
              <li><a class="dropdown-item" href="<?php echo base_url('categoria/listarcategoria');?>">Listar Categorias</a>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Proveedor
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo base_url('proveedor/registrar_Formu');?>">Registra Proveedor</a>
              <li><a class="dropdown-item" href="<?php echo base_url('proveedor/listarproveedor');?>">Listar Proveedores</a>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Producto
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo base_url('producto/registrar_Formu');?>">Registra Producto</a>
              <li><a class="dropdown-item" href="<?php echo base_url('producto/listarproducto');?>">Listar Producto</a>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Venta
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo base_url('venta/nuevoDinamico');?>">Registra Venta</a>
              <li><a class="dropdown-item" href="<?php echo base_url('venta/listarventa');?>">Listar Venta</a>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Compra
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo base_url('compra/nuevoDinamico');?>">Registra Compra</a>
              <li><a class="dropdown-item" href="<?php echo base_url('compra/listarcompra');?>">Listar Compra</a>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Reportes
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo base_url('reporte/ventatotal1');?>">Reporte 1</a>
              <li><a class="dropdown-item" href="<?php echo base_url('reporte/bajoproducto1');?>">Reporte 2</a>
              <li><a class="dropdown-item" href="<?php echo base_url('reporte/vencercana1');?>">Reporte 3</a>
              <li><a class="dropdown-item" href="<?php echo base_url('reporte/clientefrecu');?>">Reporte 4</a>
              <li><a class="dropdown-item" href="<?php echo base_url('reporte/provefrecu');?>">Reporte 5</a>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
