<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h1 class="text-white my-5 text-center"><?php echo $title ?></h1>
<form action="<?php echo base_url('cliente/actualizar/'.$clientes->codigocliente); ?>" method="POST" class="text-light bg-dark rounded-4 border border-light p-4 mx-auto" style="max-width: 300px;">
  <div class="mb-3">
    <label for="ci" class="form-label">CI:</label>
    <input type="hidden" name="ci" value="<?php echo $clientes->ci ?>">
    <?php echo $clientes->ci ?>
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Nombre:</label>
    <input type="text" class="form-control bg-white text-dark border" id="nombre" name="nombre" value="<?php echo $clientes->nombre ?>">
  </div>
  <div class="mb-3">
    <label for="apap" class="form-label">Apellido Paterno:</label>
    <input type="text" class="form-control bg-white text-dark border" id="apap" name="apap" value="<?php echo $clientes->apaterno ?>">
  </div>
  <div class="mb-3">
    <label for="apma" class="form-label">Materno:</label>
    <input type="text" class="form-control bg-white text-dark border" id="apma" name="apma" value="<?php echo $clientes->amaterno ?>">
  </div>
  <div class="mb-3">
    <label for="fono" class="form-label">Telefono:</label>
    <input type="text" class="form-control bg-white text-dark border" id="fono" name="fono" value="<?php echo $clientes->telefono ?>">
  </div>
  <div class="mb-3">
    <label for="fechre" class="form-label">Fecha de Registro:</label>
    <input type="date" class="form-control bg-white text-dark border" id="fecre" name="fechre" value="<?php echo $clientes->fecregistro ?>">
  </div>
  <div class="d-flex justify-content-center p-2">
    <button type="submit" class="btn btn-primary">Editar Cliente</button>
  </div>
</form> 


