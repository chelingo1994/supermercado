<h1 class="text-center my-5" style="color: white;">Lista de Clientes</h1>

<div class="table-responsive px-5 d-flex">
  <table class="table table-bordered table-dark table-striped">
    <thead>
      <tr class="text-center">
        <th scope="col">CI</th>
        <th scope="col">Nombre</th>
        <th scope="col">Apellido Paterno</th>
        <th scope="col">Apellido Materno</th>
        <th scope="col">Telefono</th>
        <th scope="col">Fecha de Registro</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead>
    <tbody>

      <?php if(!empty($clientes)): ?>
        <?php foreach($clientes as $cliente): ?>
          <tr>
            <th scope="row"><?php echo $cliente->ci; ?></th>
            <td><?php echo $cliente->nombre; ?></td>
            <td><?php echo $cliente->apaterno;?></td>
            <td><?php echo $cliente->amaterno;?></td>
            <td><?php echo $cliente->telefono;?></td>
            <td><?php echo $cliente->fecregistro;?></td>
            <td>
              <div class="d-flex">
                <a class="btn btn-warning m-1" href="<?php echo base_url('cliente/edit/'.$cliente->codcliente.'');?>" role="button">Editar</a>
                
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#confirmDeleteModal<?php echo $cliente->codcliente; ?>">
                  Borrar
                </button>

                <div class="modal fade" id="confirmDeleteModal<?php echo $cliente->codcliente; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Confirmar Borrado</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        ¿Estás seguro de que deseas eliminar el cliente "<?php echo $cliente->nombre; ?>"?
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <form action="<?php echo base_url('cliente/eliminar/'.$cliente->codcliente.''); ?>" method="post">
                          <button type="submit" class="btn btn-danger">Borrar</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </td>
          </tr>
        <?php endforeach;?>
      <?php else:?>
        <tr>
          <td colspan="7" class="text-center fs-5">No hay Clientes</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>




