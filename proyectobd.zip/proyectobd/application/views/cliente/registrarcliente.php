<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h1 class="text-white my-5 text-center"><?php echo $title ?></h1>
<form action="<?php echo base_url('cliente/guardar'); ?>" method="POST" class="text-light bg-dark rounded-4 border border-light p-4 mx-auto" style="max-width: 300px;">
  <div class="mb-3">
    <label for="ci" class="form-label">CI:</label>
    <input type="text" class="form-control bg-white text-dark border" id="ci" name="ci" placeholder="Ingrese el nombre">
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Nombre:</label>
    <input type="text" class="form-control bg-white text-dark border" id="nombre" name="nombre" placeholder="Ingrese Su nombre">
  </div>
  <div class="mb-3">
    <label for="apap" class="form-label">Apellido Paterno:</label>
    <input type="text" class="form-control bg-white text-dark border" id="apap" name="apap" placeholder="Ingrese su Apellido Paterno">
  </div>
  <div class="mb-3">
    <label for="apma" class="form-label">Materno:</label>
    <input type="text" class="form-control bg-white text-dark border" id="apma" name="apma" placeholder="Ingrese su Apellido Materno">
  </div>
  <div class="mb-3">
    <label for="fono" class="form-label">Telefono:</label>
    <input type="text" class="form-control bg-white text-dark border" id="fono" name="fono" placeholder="Ingrese su Telefono">
  </div>
  <div class="mb-3">
    <label for="fechre" class="form-label">Fecha de Registro:</label>
    <input type="date" class="form-control bg-white text-dark border" id="fecre" name="fechre" placeholder="Ingrese fecha de Registro">
  </div>
  <div class="d-flex justify-content-center p-2">
    <button type="submit" class="btn btn-primary">Crear Cliente</button>
  </div>
</form>