<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap/bootstrap.min.css') ?>">

  <title><?php echo 'Mi Proyecto - '.$title; ?></title>
</head>
<body class="d-flex flex-column min-vh-100 m-0 p-0">
    <?php $this->load->view('components/navbar') ?>
  <main class="bg-dark bg-gradient flex-grow-1 text-white w-100">
   <?php $this->load->view($innerViewPath); ?>
  </main>
 <?php $this->load->view('components/footer') ?>
 
<script src="<?= base_url('assets/js/bootstrap/bootstrap.bundle.min.js') ?>"></script>

</body>
</html>