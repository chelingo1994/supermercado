<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h1 class="text-white my-5 text-center"><?php echo $title ?></h1>
<form action="<?php echo base_url('empleado/actualizar/'.$empleados->codigoempleado); ?>" method="POST" class="text-light bg-dark rounded-4 border border-light p-4 mx-auto" style="max-width: 300px;">
  <div class="mb-3">
    <label for="ci" class="form-label">CI:</label>
    <input type="hidden" name="ci" value="<?php echo $empleados->ci ?>">
    <?php echo $empleados->ci ?>
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Nombre:</label>
    <input type="text" class="form-control bg-white text-dark border" id="nombre" name="nombre" value="<?php echo $empleados->nombre ?>">
  </div>
  <div class="mb-3">
    <label for="apap" class="form-label">Apellido Paterno:</label>
    <input type="text" class="form-control bg-white text-dark border" id="apap" name="apap" value="<?php echo $empleados->apaterno ?>">
  </div>
  <div class="mb-3">
    <label for="apma" class="form-label">Materno:</label>
    <input type="text" class="form-control bg-white text-dark border" id="apma" name="apma" value="<?php echo $empleados->amaterno ?>">
  </div>
  <div class="mb-3">
    <label for="fono" class="form-label">Telefono:</label>
    <input type="text" class="form-control bg-white text-dark border" id="fono" name="fono" value="<?php echo $empleados->telefono ?>">
  </div>
  <div class="mb-3">
    <label for="fechre" class="form-label">Fecha de Ingreso:</label>
    <input type="date" class="form-control bg-white text-dark border" id="fechin" name="fechin" value="<?php echo $empleados->fecingreso ?>">
  </div>
  <div class="mb-3">
    <label for="fechre" class="form-label">Sueldo:</label>
    <input type="number" class="form-control bg-white text-dark border" id="sueldo" name="sueldo" value="<?php echo $empleados->sueldo ?>">
  </div>
  <div class="d-flex justify-content-center p-2">
    <button type="submit" class="btn btn-primary">Editar Empleado</button>
  </div>
</form> 


