<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h1 class="text-white my-5 text-center"><?php echo $title ?></h1>
<form action="<?php echo base_url('proveedor/guardar'); ?>" method="POST" class="text-light bg-dark rounded-4 border border-light p-4 mx-auto" style="max-width: 300px;">
  <div class="mb-3">
    <label for="nombre" class="form-label">Nombre deL Proveedor:</label>
    <input type="text" class="form-control bg-white text-dark border" id="nombre" name="nombre" placeholder="Ingrese el nombre del Proveedor">
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Numero Telefonico:</label>
    <input type="text" class="form-control bg-white text-dark border" id="telefono" name="telefono" placeholder="Ingrese numero telefonico">
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Calle:</label>
    <input type="text" class="form-control bg-white text-dark border" id="calle" name="calle" placeholder="Ingrese la calle">
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Numero de Casa:</label>
    <input type="text" class="form-control bg-white text-dark border" id="numcasa" name="numcasa" placeholder="Ingrese el numero de casa">
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Barrio:</label>
    <input type="text" class="form-control bg-white text-dark border" id="barrio" name="barrio" placeholder="Ingrese el barrio">
  </div>
  <div class="d-flex justify-content-center p-2">
    <button type="submit" class="btn btn-primary">Crear Proveedor</button>
  </div>
</form>