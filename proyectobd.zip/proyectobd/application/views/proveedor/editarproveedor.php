<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h1 class="text-white my-5 text-center"><?php echo $title ?></h1>
<form action="<?php echo base_url('proveedor/actualizar/'.$proveedores->codproveedor); ?>" method="POST" class="text-light bg-dark rounded-4 border border-light p-4 mx-auto" style="max-width: 300px;">
  <div class="mb-3">
    <label for="ci" class="form-label">ID:</label>
    <?php echo $proveedores->codproveedor ?>
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Nombre:</label>
    <input type="text" class="form-control bg-white text-dark border" id="nombre" name="nombre" value="<?php echo $proveedores->nombre ?>">
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Numero Telefonico:</label>
    <input type="text" class="form-control bg-white text-dark border" id="telefono" name="telefono"value="<?php echo $proveedores->telefono ?>">
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Calle:</label>
    <input type="text" class="form-control bg-white text-dark border" id="calle" name="calle"value="<?php echo $proveedores->calle ?>">
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Numero de Casa:</label>
    <input type="text" class="form-control bg-white text-dark border" id="numcasa" name="numcasa" value="<?php echo $proveedores->numcasa ?>">
  </div>
  <div class="mb-3">
    <label for="nombre" class="form-label">Barrio:</label>
    <input type="text" class="form-control bg-white text-dark border" id="barrio" name="barrio" value="<?php echo $proveedores->barrio ?>">
  </div>
  <div class="d-flex justify-content-center p-2">
    <button type="submit" class="btn btn-primary">Editar Proveedor</button>
  </div>
</form> 


