<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h1 class="text-white my-5 text-center"><?php echo $title ?></h1>
<form action="<?php echo base_url('categoria/guardar'); ?>" method="POST" class="text-light bg-dark rounded-4 border border-light p-4 mx-auto" style="max-width: 300px;">
  <div class="mb-3">
    <label for="nombre" class="form-label">Nombre de la Categoria:</label>
    <input type="text" class="form-control bg-white text-dark border" id="categoria" name="nombre" placeholder="Ingrese el nombre de la categoria">
  </div>
  <div class="d-flex justify-content-center p-2">
    <button type="submit" class="btn btn-primary">Crear Categoria</button>
  </div>
</form>