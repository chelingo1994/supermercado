<h1 class="text-center my-5" style="color: white;">Lista de Ventas</h1>

<div class="table-responsive px-5 d-flex">
  <table class="table table-bordered table-dark table-striped">
    <thead>
      <tr class="text-center">
        <th scope="col">ID Venta</th>
        <th scope="col">Fecha</th>
        <th scope="col">Cliente</th>
        <th scope="col">Empleado</th>
        <th scope="col">Total (Bs)</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!empty($ventas)): ?>
        <?php foreach ($ventas as $venta): ?>
          <tr>
            <td><?= $venta->codventa; ?></td>
            <td><?= $venta->fecventa; ?></td>
            <td><?= $venta->cliente; ?></td>
            <td><?= $venta->empleado; ?></td>
            <td><?= number_format($venta->total, 2); ?></td>
            <td class="text-center">
              <div class="d-flex justify-content-center">
                <a class="btn btn-info m-1 ver-detalle" 
                  href="#" 
                  data-codventa="<?= $venta->codventa; ?>" 
                  data-toggle="modal" 
                  data-target="#detalleModal">Ver Detalle</a>

              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr>
          <td colspan="6" class="text-center fs-5">No hay ventas registradas</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Modal -->
<div class="modal fade" id="detalleModal" tabindex="-1" role="dialog" aria-labelledby="detalleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content bg-dark text-white">
      <div class="modal-header">
        <h5 class="modal-title" id="detalleModalLabel">Detalle de Venta</h5>
        <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Cerrar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="table table-bordered table-striped table-dark">
          <thead>
            <tr>
              <th>Producto</th>
              <th>Cantidad</th>
            </tr>
          </thead>
          <tbody id="detalleVentaBody">
            <!-- Contenido se carga por JS -->
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
  $('.ver-detalle').click(function(){
    const codventa = $(this).data('codventa');
    console.log(codventa);
    $('#detalleVentaBody').html('<tr><td colspan="4" class="text-center">Cargando...</td></tr>');

    $.ajax({
      url: 'obtenerDetalleVenta/' + codventa,
      method: 'GET',
      dataType: 'json',
      success: function(data) {
        let html = '';
        if(data.length > 0){
          data.forEach(function(item){
            html += `<tr>
                      <td>${item.nombre}</td>
                      <td>${item.cantidad}</td>
                    </tr>`;
          });
        } else {
          html = '<tr><td colspan="4" class="text-center">No hay detalles</td></tr>';
        }
        $('#detalleVentaBody').html(html);
      },
      error: function(){
        $('#detalleVentaBody').html('<tr><td colspan="4" class="text-center text-danger">Error al cargar detalles</td></tr>');
      }
    });
  });
});
</script>
  
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>

