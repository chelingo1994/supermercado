<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h1 class="text-center my-5"><?= $title ?></h1>

<form method="post" action="<?= site_url('venta/guardar') ?>">
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Cliente:</label>
                <select name="id_cliente" class="form-select" required>
                    <option value="">Seleccione</option>
                    <?php foreach ($clientes as $c): ?>
                        <option value="<?= $c->codcliente ?>"><?= $c->codcliente ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Empleado:</label>
                <select name="id_empleado" class="form-select" required>
                    <option value="">Seleccione</option>
                    <?php foreach ($empleados as $e): ?>
                        <option value="<?= $e->codempleado ?>"><?= $e->codempleado ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Fecha:</label>
                <input type="date" name="fecha" class="form-control" required>
            </div>
        </div>

        <h3>Productos</h3>
        <table id="productos-table" class="table table-bordered">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Subtotal</th>
                    <th>Stock Disponible</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>

        <button type="button" id="agregar" class="btn btn-primary mb-3">+ Agregar Producto</button><br><br>

        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Total Venta: Bs <span id="total">0.00</span></label>
            </div>
        </div>

        <button type="submit" class="btn btn-success">Guardar Venta</button>
    </div>
</form>

<script>
    const productosDisponibles = <?= json_encode($productos, JSON_UNESCAPED_UNICODE) ?>;
    console.log("Productos cargados:", productosDisponibles);

    function calcularSubtotal(row) {
        const cantidad = parseFloat(row.querySelector('.cantidad').value) || 0;
        const precio = parseFloat(row.querySelector('.precio').value) || 0;
        const subtotal = cantidad * precio;
        row.querySelector('.subtotal').textContent = subtotal.toFixed(2);
        return subtotal;
    }

    function actualizarTotal() {
        let total = 0;
        document.querySelectorAll('#productos-table tbody tr').forEach(row => {
            total += calcularSubtotal(row);
        });
        document.getElementById('total').textContent = total.toFixed(2);
    }

    function cargarDatosProducto(row) {
        const productId = row.querySelector('.producto').value;
        const producto = productosDisponibles.find(p => p.codproducto == productId);
        console.log("Producto seleccionado:", producto);
        if (producto) {
            row.querySelector('.precio').value = producto.precio;
            row.querySelector('.stock').textContent = producto.stock;
            row.querySelector('.cantidad').setAttribute('max', producto.stock);
            calcularSubtotal(row);
            actualizarTotal();
        }
    }

    document.getElementById('agregar').addEventListener('click', () => {
        const tbody = document.querySelector('#productos-table tbody');
        const fila = document.createElement('tr');

        let opciones = '<option value="">Seleccione</option>';
        productosDisponibles.forEach(p => {
            opciones += `<option value="${p.codproducto}">${p.nombre}</option>`;
        });

        fila.innerHTML = `
            <td><select name="id_producto[]" class="producto form-select" required>${opciones}</select></td>
            <td><input type="number" name="cantidad[]" class="cantidad form-control" min="1" value="1" required></td>
            <td><input type="number" name="precio_unitario[]" class="precio form-control" step="0.01" required></td>
            <td class="subtotal">0.00</td>
            <td><span class="stock">0</span> unidades disponibles</td>
            <td><button type="button" class="eliminar btn btn-danger btn-sm">X</button></td>
        `;
        tbody.appendChild(fila);

        fila.querySelector('.producto').addEventListener('change', () => cargarDatosProducto(fila));
        fila.querySelector('.cantidad').addEventListener('input', () => {
            calcularSubtotal(fila);
            actualizarTotal();
        });
        fila.querySelector('.precio').addEventListener('input', () => {
            calcularSubtotal(fila);
            actualizarTotal();
        });
        fila.querySelector('.eliminar').addEventListener('click', () => {
            fila.remove();
            actualizarTotal();
        });
    });
</script>
