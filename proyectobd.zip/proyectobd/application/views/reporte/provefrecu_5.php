
    <div class="container mt-5">
        <h2 class="text-center">Reporte de Proveedores mas frecuentes</h2>


    
        <!-- Mostrar los resultados del reporte -->
        <?php if (isset($proveedores)): ?>
            <table class="table table-bordered mt-4">
               <thead>
                <tr>
                    <th>Proveedor</th>
                    <th>Total Compras</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($proveedores as $proveedor): ?>
                    <tr>
                        <td><?= $proveedor->proveedor ?></td>
                        <td><?= $proveedor->total_compras ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            </table>
        <?php endif; ?>
    </div>

