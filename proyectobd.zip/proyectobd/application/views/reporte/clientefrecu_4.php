
    <div class="container mt-5">
        <h2 class="text-center">Reporte de Clientes mas frecuentes</h2>


    
        <!-- Mostrar los resultados del reporte -->
        <?php if (isset($clientes)): ?>
            <table class="table table-bordered mt-4">
               <thead>
                <tr>
                    <th>Cliente</th>
                    <th>Total Compras</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($clientes as $cliente): ?>
                    <tr>
                        <td><?= $cliente->cliente ?></td>
                        <td><?= $cliente->total_compras ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            </table>
        <?php endif; ?>
    </div>

