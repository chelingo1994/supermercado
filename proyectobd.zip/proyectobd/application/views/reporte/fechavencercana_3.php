
    <div class="container mt-5">
        <h2 class="text-center">Reporte de Productos con Fecha de vencimiento cercana</h2>

        <!-- Formulario para elegir la fecha -->
        <form action="<?= site_url('reporte/vencercana2/') ?>" method="post">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="fecha" class="form-label">Colocar Dias rangos</label>
                    <input type="text" name="dias" id="">
                </select>
                </div>
                <div class="col-md-6">
                    <button type="submit" class="btn btn-primary mt-4">Generar Reporte</button>
                </div>
            </div>
        </form>

        <!-- Mostrar los resultados del reporte -->
        <?php if (isset($productoscercanos)): ?>
            <table class="table table-bordered mt-4">
               <thead>
                <tr>
                    <th>Producto</th>
                    <th>Fecha de Vencimiento</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($productoscercanos as $producto): ?>
                    <tr>
                        <td><?= $producto->producto ?></td>
                        <td><?= $producto->fecha_vencimiento ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            </table>
        <?php endif; ?>
    </div>

