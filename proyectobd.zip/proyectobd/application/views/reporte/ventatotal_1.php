
    <div class="container mt-5">
        <h2 class="text-center">Reporte de Venta Total segun la Fecha de Venta</h2>

        <!-- Formulario para elegir la fecha -->
        <form action="<?= site_url('reporte/ventatotal2/') ?>" method="post">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="fecha" class="form-label">Selecciona la Fecha</label>
                    <select name="fecha" class="form-select" required>
                    <?php foreach ($fechas as $c): ?>
                        <option value="<?= $c->fecventa ?>"><?= $c->fecventa ?></option>
                    <?php endforeach; ?>
                </select>
                </div>
                <div class="col-md-6">
                    <button type="submit" class="btn btn-primary mt-4">Generar Reporte</button>
                </div>
            </div>
        </form>

        <!-- Mostrar los resultados del reporte -->
        <?php if (isset($totalventa)): ?>
            <h5 class="text-center">Fecha: <?= $fecha ?></h5>
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Total de Ventas</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?= number_format($totalventa->total_comprado, 2) ?> Bs</td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

