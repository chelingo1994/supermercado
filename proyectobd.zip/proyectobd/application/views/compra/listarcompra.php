<h1 class="text-center my-5" style="color: white;">Lista de Ventas</h1>

<div class="table-responsive px-5 d-flex">
  <table class="table table-bordered table-dark table-striped">
    <thead>
      <tr class="text-center">
        <th scope="col">ID Compra</th>
        <th scope="col">Fecha Compra</th>
        <th scope="col">Proveedor</th>
        <th scope="col">Total (Bs)</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!empty($compras)): ?>
        <?php foreach ($compras as $compra): ?>
          <tr>
            <td><?= $compra->codcompra; ?></td>
            <td><?= $compra->fechacompra; ?></td>
            <td><?= $compra->proveedor; ?></td>
            <td><?= $compra->totalcompra; ?></td>
            <td class="text-center">
              <div class="d-flex justify-content-center">
                <a class="btn btn-info m-1 ver-detalle" 
                  href="#" 
                  data-codcompra="<?= $compra->codcompra; ?>" 
                  data-toggle="modal" 
                  data-target="#detalleModal">Ver Detalle</a>

              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr>
          <td colspan="6" class="text-center fs-5">No hay Compras registradas</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Modal -->
<div class="modal fade" id="detalleModal" tabindex="-1" role="dialog" aria-labelledby="detalleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content bg-dark text-white">
      <div class="modal-header">
        <h5 class="modal-title" id="detalleModalLabel">Detalle de Compra</h5>
        <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Cerrar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="table table-bordered table-striped table-dark">
          <thead>
            <tr>
              <th>Producto</th>
              <th>Cantidad</th>
              <th>Precio</th>
              <th>Fecha de Vencimiento</th>
            </tr>
          </thead>
          <tbody id="detalleCompraBody">
            <!-- Contenido se carga por JS -->
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
  $('.ver-detalle').click(function(){
    const codcompra = $(this).data('codcompra');
    console.log(codcompra);
    $('#detalleCompraBody').html('<tr><td colspan="4" class="text-center">Cargando...</td></tr>');

    $.ajax({
      url: 'obtenerDetalleCompra/' + codcompra,
      method: 'GET',
      dataType: 'json',
      success: function(data) {
        let html = '';
        if(data.length > 0){
          data.forEach(function(item){
            html += `<tr>
                      <td>${item.producto}</td>
                      <td>${item.cantidad}</td>
                      <td>${item.precio}</td>
                      <td>${item.fecvencimiento}</td>
                    </tr>`;
          });
        } else {
          html = '<tr><td colspan="4" class="text-center">No hay detalles</td></tr>';
        }
        $('#detalleCompraBody').html(html);
      },
      error: function(){
        $('#detalleCompraBody').html('<tr><td colspan="4" class="text-center text-danger">Error al cargar detalles</td></tr>');
      }
    });
  });
});
</script>
  
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>

