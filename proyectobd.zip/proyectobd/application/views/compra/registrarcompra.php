<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Compra</title>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Registrar Compra</h2>

        <form method="post" action="<?= site_url('compra/guardar') ?>">
            <!-- Proveedor y Fecha -->
            <div class="mb-3">
                <label for="codProveedor" class="form-label">Proveedor:</label>
                <select name="codProveedor" id="codProveedor" class="form-select" required>
                    <option value="">Seleccione un proveedor</option>
                    <?php foreach ($proveedores as $proveedor): ?>
                        <option value="<?= $proveedor->codproveedor ?>"><?= $proveedor->nombre ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="fechaCompra" class="form-label">Fecha de la compra:</label>
                <input type="date" class="form-control" id="fechaCompra" name="fechaCompra" required>
            </div>

            <h3>Productos</h3>
            <!-- Tabla de productos -->
            <table id="productos-table" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Cantidad</th>
                        <th>Precio de Compra</th>
                        <th>Subtotal</th>
                        <th>Fecha de Vencimiento</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>

            <button type="button" id="agregarProducto" class="btn btn-primary mb-3">+ Agregar Producto</button>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">Total Compra: Bs <span id="totalCompra">0.00</span></label>
                </div>
            </div>

            <button type="submit" class="btn btn-success">Guardar Compra</button>
        </form>
    </div>

    <script>
        // Productos disponibles (pasados desde el controlador)
        const productosDisponibles = <?= json_encode($productos) ?>;

        // Función para calcular el subtotal de cada producto
        function calcularSubtotal(row) {
            const cantidad = parseFloat(row.querySelector('.cantidad').value) || 0;
            const precio = parseFloat(row.querySelector('.precioCompra').value) || 0;
            const subtotal = cantidad * precio;
            row.querySelector('.subtotal').textContent = subtotal.toFixed(2);
            return subtotal;
        }

        // Función para actualizar el total de la compra
        function actualizarTotal() {
            let total = 0;
            document.querySelectorAll('#productos-table tbody tr').forEach(row => {
                total += calcularSubtotal(row);
            });
            document.getElementById('totalCompra').textContent = total.toFixed(2);
        }

        // Función para cargar datos del producto seleccionado
        function cargarDatosProducto(row) {
            const productId = row.querySelector('.producto').value;
            const producto = productosDisponibles.find(p => p.codproducto == productId);


        }

        // Agregar productos al formulario
        document.getElementById('agregarProducto').addEventListener('click', () => {
            const tbody = document.querySelector('#productos-table tbody');
            const fila = document.createElement('tr');

            let opciones = '';
            productosDisponibles.forEach(p => {
                opciones += `<option value="${p.codproducto}">${p.nombre}</option>`;
            });

            fila.innerHTML = `
                <td><select name="codproducto[]" class="form-select producto" required>${opciones}</select></td>
                <td><input type="number" name="cantidad[]" class="form-control cantidad" min="1" value="1" required></td>
                <td><input type="number" name="preciocompra[]" class="form-control precioCompra" step="0.01" required></td>
                <td class="subtotal">0.00</td>
                <td><input type="date" name=fecvencimiento[]" class="form-control" required></td>
                <td><button type="button" class="btn btn-danger btn-sm eliminar">Eliminar</button></td>
           `;
            tbody.appendChild(fila);
            actualizarTotal();

            // Event listeners para los inputs
            fila.querySelector('.cantidad').addEventListener('input', () => actualizarTotal());
            fila.querySelector('.precioCompra').addEventListener('input', () => actualizarTotal());
            fila.querySelector('.eliminar').addEventListener('click', () => {
                fila.remove();
                actualizarTotal();
            });

            fila.querySelector('.producto').addEventListener('change', () => cargarDatosProducto(fila));

            cargarDatosProducto(fila); // Cargar datos del producto seleccionado al agregarlo
        });
    </script>
</body>
</html>
