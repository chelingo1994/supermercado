<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 class ClienteModel extends CI_Model{
     public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function insertarpersona($datospersona){
        $this->db->insert('persona',$datospersona);
    }

    public function insertarcliente($datoscliente){
        $this->db->insert('cliente',$datoscliente);
    }

    public function obtenerclientes(){
    $query=$this->db->query(" select * from persona p,cliente c where p.ci=c.cipersona");
    // Devolver los resultados
    return $query->result();
    }

    public function obtenerClienteId($codigocliente){
        $query=$this->db->query("select fecregistro,cipersona from cliente where codcliente=?",[$codigocliente]);
        if ($query->num_rows() > 0) {
    $filacliente = $query->row();
    $cicliente = $filacliente->cipersona;
} else {
    return null;  // o alguna respuesta de error
}

$query2 = $this->db->query("SELECT nombre, apaterno, amaterno, telefono FROM persona WHERE ci = ?", [$cicliente]);

if ($query2->num_rows() > 0) {
    $filapersona = $query2->row();
    $datoclientes =new stdClass();
    $datoclientes->codigocliente=$codigocliente;
    $datoclientes->ci=$cicliente;
    $datoclientes->nombre=$filapersona->nombre;
    $datoclientes->apaterno=$filapersona->apaterno;
    $datoclientes->amaterno=$filapersona->amaterno;
    $datoclientes->telefono=$filapersona->telefono;
    $datoclientes->fecregistro=$filacliente->fecregistro;
    return $datoclientes;
} else {
    return null;  // o algún otro manejo de error
}

    }

    public function editarPersona($cipersona,$datospersona){
        $this->db->query("update persona set nombre=?,apaterno=?,amaterno=?,telefono=? where ci=?",[$datospersona['nombre'],$datospersona['apaterno'],$datospersona['amaterno'],$datospersona['telefono'],$cipersona]);
    }

    public function editarCliente($codigocliente,$datoclientes){
        $this->db->query("update cliente set fecregistro=? where codcliente=?",[$datoclientes['fecregistro'],$codigocliente]);
    }
    public function eliminarCliente ($codigocliente){
        $query=$this->db->query("SELECT cipersona from cliente where codcliente=?",[$codigocliente]);
        $filacliente=$query->row();
        $cicliente=$filacliente->cipersona;

        $this->db->query("DELETE FROM cliente where codcliente=?",[$codigocliente]);
        $this->db->query("DELETE FROM persona where ci=?",[$cicliente]);
    }
 }

 ?>