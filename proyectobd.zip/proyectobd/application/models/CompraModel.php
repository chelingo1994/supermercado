<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 class CompraModel extends CI_Model{
     public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

     public function registrarcompra($compra) {
        $this->db->insert('compra',$compra);
    }

    public function compratotal($codcompra,$total){
        $this->db->query("UPDATE compra set totalcompra=? where codcompra=?",[$total,$codcompra]);
    }

      public function obtenercompras(){
    $query=$this->db->query("SELECT
            c.codCompra,
            c.fechaCompra,
            p.nombre AS proveedor,
            SUM(dc.cantidad * dc.precioCompra) AS totalCompra
        FROM compra c
        JOIN proveedor p ON c.codProveedor = p.codProveedor
        JOIN detalleCompra dc ON c.codCompra = dc.codCompra
        GROUP BY c.codCompra, c.fechaCompra, p.nombre
        ORDER BY c.fechaCompra DESC");
    // Devolver los resultados
    return $query->result();
    }

    public function obtenerPorCompra($codcompra)
    {
    $query=$this->db->query("SELECT 
    pro.nombre AS producto,
    det.cantidad,
    det.preciocompra AS precio,
    det.fecVencimiento
FROM detallecompra det
JOIN producto pro ON pro.codproducto = det.codproducto
WHERE det.codcompra = ?",[$codcompra]);

    return $query->result();
}
/*
    public function actualizarstock($codproducto,$cantidad){
        $this->db->query("UPDATE producto set stock=stock+? where codproducto=?",[$cantidad,$codproducto]);
    }

    public function obtenerventas(){
    $query=$this->db->query("SELECT
    v.codventa,
    dv.fecventa,
    c.codcliente AS cliente,
    e.codempleado AS empleado,
    SUM(dv.cantidad * dv.precioventa) AS total
FROM venta v
JOIN cliente c ON v.codcliente = c.codcliente
JOIN empleado e ON v.codempleado = e.codempleado
JOIN detalleventa dv ON v.codventa = dv.codventa
GROUP BY v.codventa, dv.fecventa, c.codcliente, e.codempleado
ORDER BY dv.fecventa DESC");
    // Devolver los resultados
    return $query->result();
    }

    public function obtenerPorVenta($codventa)
    {
    $query=$this->db->query("select pro.nombre,det.cantidad from detalleventa  det,producto pro where codventa=? and pro.codproducto=det.codproducto",[$codventa]);

    return $query->result();
}

    /*
    public function insertarproducto($datosProducto){
        $this->db->insert('producto',$datosProducto);
    }


    

    public function obtenerProductoId($codigoproducto){
        $query=$this->db->query("SELECT pro.codproducto,pro.nombre,pro.descripcion,pro.precio,pro.stock,ca.codcategoria  FROM producto pro,categoria ca where pro.codcategoria=ca.codcategoria and pro.codproducto=?",[$codigoproducto]);
        if ($query->num_rows() > 0) {
    $filaproducto = $query->row();
    return $filaproducto;
} else {
    return null;  // o alguna respuesta de error
}

    }

    public function editarProducto($codigoproducto,$datosProducto){
        $this->db->query("UPDATE producto set nombre=?,descripcion=?,precio=?,stock=?,codcategoria=? where codproducto=?",[$datosProducto['nombre'],$datosProducto['descripcion'],$datosProducto['precio'],$datosProducto['stock'],$datosProducto['codcategoria'] ,$codigoproducto]);
    }

 
    public function eliminarProducto($codigoproducto){
  
        $this->db->query("DELETE FROM producto where codproducto=?",[$codigoproducto]);

    }

        public function getAll()
    {
        return $this->db->get('categoria')->result();
    }
        */
 }

 ?>