<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 class CategoriaModel extends CI_Model{
     public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function insertarcategoria($datosCategoria){
        $this->db->insert('categoria',$datosCategoria);
    }


    public function obtenercategorias(){
    $query=$this->db->query("select * from categoria");
    // Devolver los resultados
    return $query->result();
    }

    public function obtenerCategoriaId($codigocategoria){
        $query=$this->db->query("select * from categoria where codcategoria=?",[$codigocategoria]);
        if ($query->num_rows() > 0) {
    $filacategoria = $query->row();
    $datocategorias =new stdClass();
    $datocategorias->codcategoria=$filacategoria->codcategoria;
    $datocategorias->nombre=$filacategoria->nombre;
    return $datocategorias;
} else {
    return null;  // o alguna respuesta de error
}

    }

    public function editarCategoria($codigocategoria,$datoscategoria){
        $this->db->query("UPDATE categoria set nombre=? where codcategoria=?",[$datoscategoria['nombre'],$codigocategoria]);
    }

   
    public function eliminarCategoria($codigocategoria){
  
        $this->db->query("DELETE FROM categoria where codcategoria=?",[$codigocategoria]);

    }

        public function getAll()
    {
        return $this->db->get('categoria')->result();
    }
 }

 ?>