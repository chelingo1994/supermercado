<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 class DetalleCompraModel extends CI_Model{
     public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

     public function insertardetallecompra($datodetallecompra) {
        return $this->db->insert('detallecompra', $datodetallecompra);
    }
    /*
    public function insertarproducto($datosProducto){
        $this->db->insert('producto',$datosProducto);
    }


    public function obtenerproductos(){
    $query=$this->db->query("SELECT pro.codproducto,pro.nombre,pro.descripcion,pro.precio,pro.stock,ca.nombre  as nombrecat  FROM producto pro,categoria ca where pro.codcategoria=ca.codcategoria order by pro.codproducto");
    // Devolver los resultados
    return $query->result();
    }

    public function obtenerProductoId($codigoproducto){
        $query=$this->db->query("SELECT pro.codproducto,pro.nombre,pro.descripcion,pro.precio,pro.stock,ca.codcategoria  FROM producto pro,categoria ca where pro.codcategoria=ca.codcategoria and pro.codproducto=?",[$codigoproducto]);
        if ($query->num_rows() > 0) {
    $filaproducto = $query->row();
    return $filaproducto;
} else {
    return null;  // o alguna respuesta de error
}

    }

    public function editarProducto($codigoproducto,$datosProducto){
        $this->db->query("UPDATE producto set nombre=?,descripcion=?,precio=?,stock=?,codcategoria=? where codproducto=?",[$datosProducto['nombre'],$datosProducto['descripcion'],$datosProducto['precio'],$datosProducto['stock'],$datosProducto['codcategoria'] ,$codigoproducto]);
    }

 
    public function eliminarProducto($codigoproducto){
  
        $this->db->query("DELETE FROM producto where codproducto=?",[$codigoproducto]);

    }

        public function getAll()
    {
        return $this->db->get('categoria')->result();
    }
        */
 }

 ?>