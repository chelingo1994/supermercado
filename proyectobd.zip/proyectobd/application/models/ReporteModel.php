<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 class ReporteModel extends CI_Model{
     public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

     public function fechas(){
        $query=$this->db->query("select fecventa from venta");
        return $query->result();
     }

     public function obtenerVentaTotal($fecha){
        $query=$this->db->query("SELECT 
    SUM(dv.cantidad * dv.precioVenta) AS total_comprado
FROM detalleventa dv
JOIN venta v ON v.codVenta = dv.codVenta
WHERE v.fecVenta = ?",[$fecha]);

        return $query->row();
     }

     public function productosbajo($minimo){
        $query=$this->db->query("SELECT 
        p.nombre AS producto,
        p.stock AS cantidad_disponible
        FROM producto p
        WHERE p.stock <= ?
        ORDER BY p.stock ASC",[$minimo]);
        return $query->result();
     }

     public function rangodias($dias){
    $diasjunto = $dias . ' days';  // Concatenamos el valor de días con el string ' days'
    $query = $this->db->query("
        SELECT 
            p.nombre AS producto,
            dc.fecVencimiento AS fecha_vencimiento
        FROM detalleCompra dc
        JOIN producto p ON p.codProducto = dc.codProducto
        WHERE dc.fecVencimiento BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL ?
        ORDER BY dc.fecVencimiento ASC", [$diasjunto]);  // Pasamos el valor del intervalo como parámetro

    return $query->result();  // Retornamos los resultados
}

    public function clientefrecu(){
        $query=$this->db->query("SELECT 
    c.codcliente AS cliente,
    COUNT(v.codVenta) AS total_compras
    FROM cliente c
    JOIN venta v ON c.codCliente = v.codCliente
    GROUP BY c.codcliente
    ORDER BY total_compras DESC");
    return $query->result();
    }

    public function provefrecu(){
        $query=$this->db->query("SELECT 
    p.nombre AS proveedor,
    COUNT(c.codCompra) AS total_compras
    FROM proveedor p
    JOIN compra c ON p.codProveedor = c.codProveedor
    GROUP BY p.nombre
    ORDER BY total_compras DESC");
    return $query->result();
    }

 }

 ?>