<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 class ProveedorModel extends CI_Model{
     public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function insertarproveedor($datosProveedor){
        $this->db->insert('proveedor',$datosProveedor);
    }


    public function obtenerproveedores(){
    $query=$this->db->query("select * from proveedor");
    // Devolver los resultados
    return $query->result();
    }

    public function obtenerProveedorId($codigoproveedor){
        $query=$this->db->query("select * from proveedor where codproveedor=?",[$codigoproveedor]);
        if ($query->num_rows() > 0) {
    $filaproveedor = $query->row();
    $datoproveedores =new stdClass();
    $datoproveedores->codproveedor=$filaproveedor->codproveedor;
    $datoproveedores->nombre=$filaproveedor->nombre;
    $datoproveedores->telefono=$filaproveedor->telefono;
    $datoproveedores->calle=$filaproveedor->calle;
    $datoproveedores->numcasa=$filaproveedor->numcasa;
    $datoproveedores->barrio=$filaproveedor->barrio;
    return $datoproveedores;
} else {
    return null;  // o alguna respuesta de error
}

    }

    public function editarProveedor($codigoproveedor,$datosProveedor){
        $this->db->query("UPDATE proveedor set nombre=?,telefono=?,calle=?,numcasa=?,barrio=? where codproveedor=?",[$datosProveedor['nombre'],$datosProveedor['telefono'],$datosProveedor['calle'],$datosProveedor['numcasa'],$datosProveedor['barrio'],$codigoproveedor]);
    }

   
    public function eliminarProveedor($codigoproveedor){
  
        $this->db->query("DELETE FROM proveedor where codproveedor=?",[$codigoproveedor]);

    }
 }

 ?>