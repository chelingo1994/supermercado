<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 class EmpleadoModel extends CI_Model{
     public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function insertarpersona($datospersona){
        $this->db->insert('persona',$datospersona);
    }

    public function insertarempleado($datosempleado){
        $this->db->insert('empleado',$datosempleado);
    }

    public function obtenerempleados(){
    $query=$this->db->query(" select * from persona p,empleado e where p.ci=e.cipersona");
    // Devolver los resultados
    return $query->result();
    }

    public function obtenerEmpleadoId($codigoempleado){
        $query=$this->db->query("select fecingreso,sueldo,cipersona from empleado where codempleado=?",[$codigoempleado]);
        if ($query->num_rows() > 0) {
    $filaempleado = $query->row();
    $ciempleado = $filaempleado->cipersona;
} else {
    return null;  // o alguna respuesta de error
}

$query2 = $this->db->query("SELECT nombre, apaterno, amaterno, telefono FROM persona WHERE ci = ?", [$ciempleado]);

if ($query2->num_rows() > 0) {
    $filapersona = $query2->row();
    $datoempleados =new stdClass();
    $datoempleados->codigoempleado=$codigoempleado;
    $datoempleados->ci=$ciempleado;
    $datoempleados->nombre=$filapersona->nombre;
    $datoempleados->apaterno=$filapersona->apaterno;
    $datoempleados->amaterno=$filapersona->amaterno;
    $datoempleados->telefono=$filapersona->telefono;
    $datoempleados->fecingreso=$filaempleado->fecingreso;
    $datoempleados->sueldo=$filaempleado->sueldo;
    return $datoempleados;
} else {
    return null;  // o algún otro manejo de error
}

    }

    public function editarPersona($cipersona,$datospersona){
        $this->db->query("update persona set nombre=?,apaterno=?,amaterno=?,telefono=? where ci=?",[$datospersona['nombre'],$datospersona['apaterno'],$datospersona['amaterno'],$datospersona['telefono'],$cipersona]);
    }

    public function editarEmpleado($codigoempleado,$datoempleados){
        $this->db->query("update empleado set fecingreso=?,sueldo=? where codempleado=?",[$datoempleados['fecingreso'],$datoempleados['sueldo'],$codigoempleado]);
    }
    public function eliminarEmpleado($codigoempleado){
        $query=$this->db->query("SELECT cipersona from empleado where codempleado=?",[$codigoempleado]);
        $filaempleado=$query->row();
        $ciempleado=$filaempleado->cipersona;

        $this->db->query("DELETE FROM empleado where codempleado=?",[$codigoempleado]);
        $this->db->query("DELETE FROM persona where ci=?",[$ciempleado]);
    }
 }

 ?>