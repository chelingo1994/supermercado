<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categoria extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->load->model('categoriamodel');
	}

    public function registrar_Formu(){
        $mainData=[
			'title'=>'Nueva Categoria',
			'innerViewPath'=>'categoria/registrarcategoria',
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function guardar(){
        $datosCategoria=[
            'nombre'=>$this->input->post('nombre'),
        ];

        $this->categoriamodel->insertarcategoria($datosCategoria);
        redirect('principal');
    }

    public function listarcategoria(){
        $mainData=[
			'title'=>'Mi Lista de Categoria',
			'innerViewPath'=>'categoria/listarcategoria',
			'categorias'=>$this->categoriamodel->obtenercategorias(),
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function edit($codigocategoria){
		$categoria=$this->categoriamodel->obtenerCategoriaId($codigocategoria);
		if ($categoria==null) {
			show_404();
		}
		
		
		$mainData=[
			'title'=>'Editar Categoria #'.$codigocategoria,
			'innerViewPath'=>'categoria/editarcategoria',
			'categorias'=>$categoria,
		];
		$this->load->view('layouts/main',$mainData);
	}

    public function actualizar($codigocategoria){
        $datoscategoria=[
            'nombre'=>$this->input->post('nombre'),

        ];
        $this->categoriamodel->editarCategoria($codigocategoria,$datoscategoria);
        redirect('categoria/listarcategoria');
    }

    public function eliminar($codigocategoria){
        $this->categoriamodel->eliminarCategoria($codigocategoria);
        redirect('categoria/listarcategoria');  
    }

}

?>