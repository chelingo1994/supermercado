<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Compra extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->load->model('productomodel');
        $this->load->model('compramodel');
        $this->load->model('proveedormodel');
        $this->load->model('detallecompramodel');
	}

    public function nuevoDinamico() {

    $data['proveedores'] = $this->proveedormodel->obtenerproveedores();
    $data['productos'] = $this->productomodel->obtenerproductos();
    $data['title']='Nueva Compra';
    $data['innerViewPath']='compra/registrarcompra';
    $this->load->view('layouts/main', $data);

}

    

    public function guardar(){
      
       $compra=[
            'codproveedor'=>$this->input->post('codProveedor'),
            'fechacompra'=>$this->input->post('fechaCompra'),
            'totalcompra'=>0
        ];

        $this->compramodel->registrarcompra($compra);
        $codcompra=$this->db->insert_id();
        $productos=$this->input->post('codproducto');
        $preciocompra=$this->input->post('preciocompra');
        $cantidades=$this->input->post('cantidad');
        $fechasven=$this->input->post('fecvencimiento');
        $total=0;
        for ($i = 0; $i < count($productos); $i++) {
        $datosdetalle = [
            'codcompra' => $codcompra,
            'codproducto' => $productos[$i],
            'cantidad' => $cantidades[$i],
            'preciocompra' => $preciocompra[$i],
            'fecvencimiento'=>$fechasven[$i]
        ];
        
            $this->detallecompramodel->insertardetallecompra($datosdetalle);
            $this->productomodel->actulizarstockcompra($datosdetalle['codproducto'],$datosdetalle['cantidad']);

            $total+=$cantidades[$i]*$preciocompra[$i];
        }
        $this->compramodel->compratotal($codcompra,$total);
        redirect('principal');
    }

    public function listarcompra(){
        $mainData=[
			'title'=>'Mi Lista de Compras',
			'innerViewPath'=>'compra/listarcompra',
			'compras'=>$this->compramodel->obtenercompras(),
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function obtenerDetalleCompra($codcompra)
    {
    $detalle = $this->compramodel->obtenerPorCompra($codcompra);

    echo json_encode($detalle); // Se devuelve como JSON para el modal
    }
/*
    public function listarventa(){
        $mainData=[
			'title'=>'Mi Lista de Ventas',
			'innerViewPath'=>'venta/listarventa',
			'ventas'=>$this->ventamodel->obtenerventas(),
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function obtenerDetalleVenta($codventa)
    {
    $detalle = $this->ventamodel->obtenerPorVenta($codventa);

    echo json_encode($detalle); // Se devuelve como JSON para el modal
    }

    /*
    public function edit($codigoproducto){
		$producto=$this->productomodel->obtenerProductoId($codigoproducto);
		if ($producto==null) {
			show_404();
		}
		
		
		$mainData=[
			'title'=>'Editar Producto #'.$codigoproducto,
			'innerViewPath'=>'producto/editarproducto',
			'productos'=>$producto,
            'categorias'=>$this->categoriamodel->getAll(),
		];
		$this->load->view('layouts/main',$mainData);
	}
    
    public function actualizar($codigoproducto){
        $datosProducto=[
            'nombre'=>$this->input->post('nombre'),
            'descripcion'=>$this->input->post('descripcion'),
            'precio'=>$this->input->post('precio'),
            'stock'=>$this->input->post('stock'),
            'codcategoria'=>$this->input->post('categoria'),
        ];
        $this->productomodel->editarProducto($codigoproducto,$datosProducto);
        redirect('producto/listarproducto');
    }

    public function eliminar($codigoproducto){
        $this->productomodel->eliminarProducto($codigoproducto);
        redirect('producto/listarproducto');
    }
*/
}

?>