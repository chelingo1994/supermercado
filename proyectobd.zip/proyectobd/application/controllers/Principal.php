<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Principal extends CI_Controller {
	//Index ->muestra lista de productos->Vista

	public function __construct()
	{
		parent::__construct();
		
	}

    public function index(){
	
		$mainData=[
			'title'=>'Pagina Principal',
			'innerViewPath'=>'index',
		];
		$this->load->view('layouts/main',$mainData);
	}
}   
    ?>