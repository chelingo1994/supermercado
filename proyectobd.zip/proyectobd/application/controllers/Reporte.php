<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reporte extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->load->model('reportemodel');

	}
    //REPORTE 1
    public function ventatotal1(){
        $mainData=[
			'innerViewPath'=>'reporte/ventatotal_1',
            'fechas'=>$this->reportemodel->fechas(),
            'title'=>'Reporte 1'
		];
		$this->load->view('layouts/main',$mainData);
    }
     public function ventatotal2(){

        $datos=[
			'innerViewPath'=>'reporte/ventatotal_1',
            'fecha'=>$this->input->post('fecha'),
            'fechas'=>$this->reportemodel->fechas(),
            'totalventa'=>$this->reportemodel->obtenerVentaTotal($this->input->post('fecha')),
            'title'=>'Reporte 1'
		];
        $this->load->view('layouts/main', $datos);
    
        
    }
    

    public function bajoproducto1(){
        $mainData=[
			'innerViewPath'=>'reporte/productobajo_2',
            'title'=>'Reporte 2'
		];
		$this->load->view('layouts/main',$mainData);
        
    }
    public function bajoproducto2(){
        $mainData=[
			'innerViewPath'=>'reporte/productobajo_2',
            'productosBajoStock'=>$this->reportemodel->productosbajo($this->input->post('minimo')),
            'title'=>'Reporte 2'
		];
		$this->load->view('layouts/main',$mainData);
    }
     public function vencercana1(){
        $mainData=[
			'innerViewPath'=>'reporte/fechavencercana_3',
            'title'=>'Reporte 3'
		];
		$this->load->view('layouts/main',$mainData);
    }
    public function vencercana2(){
        $mainData=[
			'innerViewPath'=>'reporte/fechavencercana_3',
            'productoscercanos'=>$this->reportemodel->rangodias($this->input->post('dias')),
            'title'=>'Reporte 3'
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function clientefrecu(){
        $mainData=[
			'innerViewPath'=>'reporte/clientefrecu_4',
            'clientes'=>$this->reportemodel->clientefrecu(),
            'title'=>'Reporte 4'
		];
		$this->load->view('layouts/main',$mainData);
        
    }

    public function provefrecu(){
        $mainData=[
			'innerViewPath'=>'reporte/provefrecu_5',
            'proveedores'=>$this->reportemodel->provefrecu(),
            'title'=>'Reporte 5'
		];
		$this->load->view('layouts/main',$mainData);
        
    }
   
}

?>