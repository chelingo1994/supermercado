<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cliente extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->load->model('clientemodel');
	}

    public function registrar_Formu(){
        $mainData=[
			'title'=>'Nuevo CLiente',
			'innerViewPath'=>'cliente/registrarcliente',
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function guardar(){
        $datosPersona=[
            'ci'=>$this->input->post('ci'),
            'nombre'=>$this->input->post('nombre'),
            'apaterno'=>$this->input->post('apap'),
            'amaterno'=>$this->input->post('apma'),
            'telefono'=>$this->input->post('fono'),
        ];

        $this->clientemodel->insertarpersona($datosPersona);

        $datoscliente=[
            'fecregistro'=>$this->input->post('fechre'),
            'cipersona'=>$this->input->post('ci'),
        ];
        $this->clientemodel->insertarcliente($datoscliente);
        redirect('principal');
    }

    public function listarclientes(){
        $mainData=[
			'title'=>'Mi Lista de Clientes',
			'innerViewPath'=>'cliente/listarcliente',
			'clientes'=>$this->clientemodel->obtenerclientes(),
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function edit($codigocliente){
		$cliente=$this->clientemodel->obtenerClienteId($codigocliente);
		if ($cliente==null) {
			show_404();
		}
		
		
		$mainData=[
			'title'=>'Editar Cliente #'.$codigocliente,
			'innerViewPath'=>'cliente/editarcliente',
			'clientes'=>$cliente,
		];
		$this->load->view('layouts/main',$mainData);
	}

    public function actualizar($codigocliente){
        $cipersona=$this->input->post('ci');
        $datosPersona=[
            'nombre'=>$this->input->post('nombre'),
            'apaterno'=>$this->input->post('apap'),
            'amaterno'=>$this->input->post('apma'),
            'telefono'=>$this->input->post('fono'),
        ];

        $this->clientemodel->editarPersona($cipersona,$datosPersona);

        $datoscliente=[
            'fecregistro'=>$this->input->post('fechre'),
        ];
        $this->clientemodel->editarCliente($codigocliente,$datoscliente);
        redirect('cliente/listarclientes');
    }

    public function eliminar($codigocliente){
        $this->clientemodel->eliminarCliente($codigocliente);
        redirect('cliente/listarclientes');    
    }

}

?>