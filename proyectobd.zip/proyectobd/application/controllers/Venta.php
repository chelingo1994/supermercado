<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Venta extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->load->model('productomodel');
        $this->load->model('clientemodel');
        $this->load->model('empleadomodel');
        $this->load->model('ventamodel');
        $this->load->model('detalleventamodel');
	}

    public function nuevoDinamico() {

    $data['clientes'] = $this->clientemodel->obtenerclientes();
    $data['empleados'] = $this->empleadomodel->obtenerempleados();
    $data['productos'] = $this->productomodel->obtenerproductos();
    $data['title']='Nueva Venta';
    $data['innerViewPath']='venta/registrarventa';
    $this->load->view('layouts/main', $data);

}

    

    public function guardar(){
        $venta=[
            'codcliente'=>$this->input->post('id_cliente'),
            'codempleado'=>$this->input->post('id_empleado'),
            'fecventa'=>$this->input->post('fecha'),
        ];

        $this->ventamodel->insertarventa($venta);
        $idventa=$this->db->insert_id();
        $productos = $this->input->post('id_producto');
        $cantidades = $this->input->post('cantidad');
        $precios = $this->input->post('precio_unitario');

    for ($i = 0; $i < count($productos); $i++) {
        $datosdetalle = [
            'codventa' => $idventa,
            'codproducto' => $productos[$i],
            'cantidad' => $cantidades[$i],
            'precioventa' => $precios[$i]
        ];
            $this->detalleventamodel->insertardetalleveta($datosdetalle);
            $this->productomodel->actulizarstockventa($datosdetalle['codproducto'],$datosdetalle['cantidad']);
        }
        redirect('principal');
    }

    public function listarventa(){
        $mainData=[
			'title'=>'Mi Lista de Ventas',
			'innerViewPath'=>'venta/listarventa',
			'ventas'=>$this->ventamodel->obtenerventas(),
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function obtenerDetalleVenta($codventa)
    {
    $detalle = $this->ventamodel->obtenerPorVenta($codventa);

    echo json_encode($detalle); // Se devuelve como JSON para el modal
    }

    /*
    public function edit($codigoproducto){
		$producto=$this->productomodel->obtenerProductoId($codigoproducto);
		if ($producto==null) {
			show_404();
		}
		
		
		$mainData=[
			'title'=>'Editar Producto #'.$codigoproducto,
			'innerViewPath'=>'producto/editarproducto',
			'productos'=>$producto,
            'categorias'=>$this->categoriamodel->getAll(),
		];
		$this->load->view('layouts/main',$mainData);
	}
    
    public function actualizar($codigoproducto){
        $datosProducto=[
            'nombre'=>$this->input->post('nombre'),
            'descripcion'=>$this->input->post('descripcion'),
            'precio'=>$this->input->post('precio'),
            'stock'=>$this->input->post('stock'),
            'codcategoria'=>$this->input->post('categoria'),
        ];
        $this->productomodel->editarProducto($codigoproducto,$datosProducto);
        redirect('producto/listarproducto');
    }

    public function eliminar($codigoproducto){
        $this->productomodel->eliminarProducto($codigoproducto);
        redirect('producto/listarproducto');
    }
*/
}

?>