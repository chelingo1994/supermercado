<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Producto extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->load->model('productomodel');
        $this->load->model('categoriamodel');
	}

    public function registrar_Formu(){
        $mainData=[
			'title'=>'Nuevo Producto',
			'innerViewPath'=>'producto/registrarproducto',
            'categorias'=>$this->categoriamodel->getAll(),
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function guardar(){
        $datosProducto=[
            'nombre'=>$this->input->post('nombre'),
            'descripcion'=>$this->input->post('descripcion'),
            'precio'=>$this->input->post('precio'),
            'stock'=>$this->input->post('stock'),
            'codcategoria'=>$this->input->post('categoria'),
        ];

        $this->productomodel->insertarproducto($datosProducto);
        redirect('principal');
    }

    public function listarproducto(){
        $mainData=[
			'title'=>'Mi Lista de Productos',
			'innerViewPath'=>'producto/listarproducto',
			'productos'=>$this->productomodel->obtenerproductos(),
		];
		$this->load->view('layouts/main',$mainData);
    }
    
    public function edit($codigoproducto){
		$producto=$this->productomodel->obtenerProductoId($codigoproducto);
		if ($producto==null) {
			show_404();
		}
		
		
		$mainData=[
			'title'=>'Editar Producto #'.$codigoproducto,
			'innerViewPath'=>'producto/editarproducto',
			'productos'=>$producto,
            'categorias'=>$this->categoriamodel->getAll(),
		];
		$this->load->view('layouts/main',$mainData);
	}
    
    public function actualizar($codigoproducto){
        $datosProducto=[
            'nombre'=>$this->input->post('nombre'),
            'descripcion'=>$this->input->post('descripcion'),
            'precio'=>$this->input->post('precio'),
            'stock'=>$this->input->post('stock'),
            'codcategoria'=>$this->input->post('categoria'),
        ];
        $this->productomodel->editarProducto($codigoproducto,$datosProducto);
        redirect('producto/listarproducto');
    }

    public function eliminar($codigoproducto){
        $this->productomodel->eliminarProducto($codigoproducto);
        redirect('producto/listarproducto');
    }

    
}

?>