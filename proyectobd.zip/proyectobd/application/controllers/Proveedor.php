<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proveedor extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->load->model('proveedormodel');
	}

    public function registrar_Formu(){
        $mainData=[
			'title'=>'Nuevo Proveedor',
			'innerViewPath'=>'proveedor/registrarproveedor',
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function guardar(){
        $datosProveedor=[
            'nombre'=>$this->input->post('nombre'),
            'telefono'=>$this->input->post('telefono'),
            'calle'=>$this->input->post('calle'),
            'numcasa'=>$this->input->post('numcasa'),
            'barrio'=>$this->input->post('barrio'),
        ];

        $this->proveedormodel->insertarproveedor($datosProveedor);
        redirect('principal');
    }

    public function listarproveedor(){
        $mainData=[
			'title'=>'Mi Lista de Proveedores',
			'innerViewPath'=>'proveedor/listarproveedor',
			'proveedores'=>$this->proveedormodel->obtenerproveedores(),
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function edit($codigoproveedor){
		$proveedor=$this->proveedormodel->obtenerProveedorId($codigoproveedor);
		if ($proveedor==null) {
			show_404();
		}
		
		
		$mainData=[
			'title'=>'Editar Proveedor #'.$codigoproveedor,
			'innerViewPath'=>'proveedor/editarproveedor',
			'proveedores'=>$proveedor,
		];
		$this->load->view('layouts/main',$mainData);
	}

    public function actualizar($codigoproveedor){
        $datosProveedor=[
            'nombre'=>$this->input->post('nombre'),
            'telefono'=>$this->input->post('telefono'),
            'calle'=>$this->input->post('calle'),
            'numcasa'=>$this->input->post('numcasa'),
            'barrio'=>$this->input->post('barrio'),
        ];
        $this->proveedormodel->editarProveedor($codigoproveedor,$datosProveedor);
        redirect('proveedor/listarproveedor');
    }

    public function eliminar($codigoproveedor){
        $this->proveedormodel->eliminarProveedor($codigoproveedor);
        redirect('proveedor/listarproveedor');
    }

}

?>