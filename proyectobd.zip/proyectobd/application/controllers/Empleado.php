<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Empleado extends CI_Controller {
    public function __construct()
	{
		parent::__construct();
		$this->load->model('empleadomodel');
	}

    public function registrar_Formu(){
        $mainData=[
			'title'=>'Nuevo Empleado',
			'innerViewPath'=>'empleado/registrarempleado',
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function guardar(){
        $datosPersona=[
            'ci'=>$this->input->post('ci'),
            'nombre'=>$this->input->post('nombre'),
            'apaterno'=>$this->input->post('apap'),
            'amaterno'=>$this->input->post('apma'),
            'telefono'=>$this->input->post('fono'),
        ];

        $this->empleadomodel->insertarpersona($datosPersona);

        $datosempleado=[
            'fecingreso'=>$this->input->post('fecin'),
            'sueldo'=>$this->input->post('sueldo'),
            'cipersona'=>$this->input->post('ci'),
        ];
        $this->empleadomodel->insertarempleado($datosempleado);
        redirect('principal');
    }

    public function listarempleados(){
        $mainData=[
			'title'=>'Mi Lista de Empleados',
			'innerViewPath'=>'empleado/listarempleado',
			'empleados'=>$this->empleadomodel->obtenerempleados(),
		];
		$this->load->view('layouts/main',$mainData);
    }

    public function edit($codigoempleado){
		$empleado=$this->empleadomodel->obtenerEmpleadoId($codigoempleado);
		if ($empleado==null) {
			show_404();
		}
		
		
		$mainData=[
			'title'=>'Editar Empleado #'.$codigoempleado,
			'innerViewPath'=>'empleado/editarempleado',
			'empleados'=>$empleado,
		];
		$this->load->view('layouts/main',$mainData);
	}

    public function actualizar($codigoempleado){
        $cipersona=$this->input->post('ci');
        $datosPersona=[
            'nombre'=>$this->input->post('nombre'),
            'apaterno'=>$this->input->post('apap'),
            'amaterno'=>$this->input->post('apma'),
            'telefono'=>$this->input->post('fono'),
        ];

        $this->empleadomodel->editarPersona($cipersona,$datosPersona);

        $datosempleado=[
            'fecingreso'=>$this->input->post('fechin'),
            'sueldo'=>$this->input->post('sueldo'),
        ];
        $this->empleadomodel->editarEmpleado($codigoempleado,$datosempleado);
        redirect('empleado/listarempleados');
    }

    public function eliminar($codigoempleado){
        $this->empleadomodel->eliminarEmpleado($codigoempleado);
        redirect('empleado/listarempleados');  
    }

}

?>